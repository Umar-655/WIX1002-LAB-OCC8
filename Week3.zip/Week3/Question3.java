/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;
import java.util.Scanner;
/**
 *
 * @author umr
 */
public class Question3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for sales volume
        System.out.print("Enter the sales volume: ");
        double salesVolume = scanner.nextDouble();

        double commission = 0.0;

        if (salesVolume <= 100) {
            commission = salesVolume * 0.05;
        } else if (salesVolume > 100 && salesVolume <= 500) {
            commission = salesVolume * 0.075;
        } else if (salesVolume > 500 && salesVolume <= 1000) {
            commission = salesVolume * 0.10;
        } else {
            commission = salesVolume * 0.125;
        }

        System.out.printf("Total Commission: %.2f%n", commission);
    }
}   

