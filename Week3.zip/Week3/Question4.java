/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;

import java.util.Random;

public class Question4 {
    public static void main(String[] args) {
        Random random = new Random();

        // Player 1 rolls twice
        int p1Roll1 = random.nextInt(6) + 1;
        int p1Roll2 = random.nextInt(6) + 1;
        int p1Total = p1Roll1 + p1Roll2;

        // Player 2 rolls twice
        int p2Roll1 = random.nextInt(6) + 1;
        int p2Roll2 = random.nextInt(6) + 1;
        int p2Total = p2Roll1 + p2Roll2;

        //Player 1 results
        System.out.println("--- Player 1 ---");
        System.out.println("Roll 1: " + p1Roll1);
        System.out.println("Roll 2: " + p1Roll2);
        System.out.println("Total Score: " + p1Total + "\n");

        //Player 2 results
        System.out.println("--- Player 2 ---");
        System.out.println("Roll 1: " + p2Roll1);
        System.out.println("Roll 2: " + p2Roll2);
        System.out.println("Total Score: " + p2Total + "\n");

        System.out.println("--- Result ---");
        if (p1Total > p2Total) {
            System.out.println("Player 1 wins");
        } else if (p2Total > p1Total) {
            System.out.println("Player 2 wins");
        } else {
            System.out.println("It's a tie");
        }
    }
}
