/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;

/**
 *
 * @author umr
 */
    import java.util.Scanner;

public class Question6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        int radius = scanner.nextInt();

        System.out.print("Enter coordinate x: ");
        int x = scanner.nextInt();
        
        System.out.print("Enter coordinate y: ");
        int y = scanner.nextInt();

        double distance = Math.sqrt(x * x + y * y);

        if (distance < radius) {
            System.out.println("Point (" + x + ", " + y + ") is INSIDE the circle.");
        } else if (distance > radius) {
            System.out.println("Point (" + x + ", " + y + ") is OUTSIDE the circle.");
        } else {
            System.out.println("Point (" + x + ", " + y + ") is ON the circumference.");
        }

    }
}
