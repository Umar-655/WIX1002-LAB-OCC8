/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// Write the java statements that used the if statement to find the biggest number among
// three given integers.
package Week3;

import java.util.Scanner;

public class Tutorial4 {

    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        System.out.println("Please enter a integer (x) ");
        int x = num.nextInt();
        System.out.println("Please enter a integer (y) ");
        int y = num.nextInt();
        System.out.println("Please enter a integer (z) ");
        int z = num.nextInt();
        if (x > y && x > z) {
            System.out.println("integer x is the largest");
        }
        if (y > x && y > z) {
            System.out.println("integer y is the largest");
        }
        if (z > x && z > y) {
            System.out.println("integer z is the largest");
        }
        if (x == y && x == z && y == z) {
            System.out.println("All integers are equal");
        }
        if (x == y && x > z) {
            System.out.println("Integer x and y is equal and it is greater than z");
        }
        if (x == z && x > y) {
            System.out.println("Integer x and z is equal and it is greater than y");
        }
        if (y == z && y > x) {
            System.out.println("Integer y and z is equal and it is greater than z");
        }
    }
}
