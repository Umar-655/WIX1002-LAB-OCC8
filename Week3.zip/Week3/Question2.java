/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;
import java.util.Random;
/**
 *
 * @author umr
 */
public class Question2 {
    public static void main(String[] args){
        Random gamble = new Random();
        int random = gamble.nextInt(6);
        switch (random) {
            case(1) -> System.out.println("1 is one.");
            case(2) -> System.out.println("2 is two.");
            case(3) -> System.out.println("3 is three.");
            case(4) -> System.out.println("4 is four.");
            case(5) -> System.out.println("5 is five.");
        }
    }
}
