/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;


//Write the java statements that determine whether the Leap year. A Leap year is
//divisible by 4 but not by 100. However, a Leap year is also divisible by 400.


import java.util.Scanner;

public class Tutorial5 {

    public static void main(String[] args) {
        Scanner yr = new Scanner(System.in);
        System.out.println("Enter a year: ");
        int year = yr.nextInt();
        if (year % 4 == 0 && year % 100 != 0) {
            System.out.println(year + " is a Leap year.");
        } else {
            System.out.println(year + " is not a Leap year.");
        }
    }
}
