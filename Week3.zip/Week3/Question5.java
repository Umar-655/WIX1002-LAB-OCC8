/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;
import java.util.Scanner;

public class Question5 {
    public static void main(String[] args){
        Scanner number = new Scanner(System.in);
        System.out.println ("Enter value for (a): ");
        int a = number.nextInt();
        System.out.println ("Enter value for (b): ");
        int b = number.nextInt();
        System.out.println ("Enter value for (c): ");
        int c = number.nextInt();
        System.out.println ("Enter value for (d): ");
        int d = number.nextInt();
        System.out.println ("Enter value for (e): ");
        int e = number.nextInt();
        System.out.println ("Enter value for (f): ");
        int f = number.nextInt();
        
        // Cramers's Rule
        if ((a*d) - (b*c) == 0) {
            System.out.println("The equation has no solution.");
        } else {
            int x = ((e*d) - (b*f))/((a*d) - (b*c));
            int y = ((a*f) - (e*c))/((a*d)-(b*c));
            System.out.println("Solution of x is " + x);
            System.out.println("Solution of y is " + y);
        } 
    }
}
