/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week3;
import java.util.Scanner;

public class Question1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter two integer number: ");
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();
        System.out.println("Enter the operand: ");
        char oper = scanner.next().charAt(0);
        
        switch (oper) {
            case '+' -> System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
            case '-' -> System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
            case '*' -> System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
            case '/' -> System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
            case '%' -> System.out.println(num1 + " % " + num2 + " = " + (num1 % num2));
            default -> System.out.println("Invalid operator.");
            }   
        }   
    }

