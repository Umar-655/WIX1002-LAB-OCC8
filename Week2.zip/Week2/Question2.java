/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week2;

/**
 *
 * @author umr
 */
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
    
        Scanner input = new Scanner(System.in);

        // Reading inputs from user
        System.out.print("Enter car price (P): ");
        double P = input.nextDouble();

        System.out.print("Enter down payment (D): ");
        double D = input.nextDouble();

        System.out.print("Enter interest rate in % (R): ");
        double R = input.nextDouble();

        System.out.print("Enter loan duration in years (Y): ");
        double Y = input.nextDouble();

        // Formula: M = (P - D) * (1 + R*Y/100) / (Y * 12)
        double M = (P - D) * (1 + R * Y / 100) / (Y * 12);

        // Output formatted to 2 decimal places
        System.out.printf("Monthly Payment (M): RM %.2f\n", M);

        input.close();
    }
}
