package Week2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author umr
 */

    import java.util.Scanner;

public class Question1{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter Temperature in Fahrenheit: ");
        int Fahrenheit = input.nextInt();

        double celcius = (Fahrenheit - 32) / 1.8;
        System.out.printf("Celcius = %.2f\n", celcius);
    }
}
