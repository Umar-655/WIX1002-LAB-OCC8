/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week2;

/**
 *
 * @author umr
 */
    import java.util.Random;

public class Question5 {

    public static void main(String[] args) {
        Random rand = new Random();

        int number = rand.nextInt(10001);

        int temp = number;
        int sum = 0;

        // Loop to extract each digit using % 10 and / 10
        while (temp > 0) {
            sum += temp % 10; // Extract last digit and add to sum
            temp /= 10;        // Remove last digit
        }

        System.out.println("Random Number: " + number);
        System.out.println("Sum of digits: " + sum);
    }
}
