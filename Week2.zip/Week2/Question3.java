/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week2;

import java.util.Random;
 
public class Question3 {
    public static void main(String[] args) {

        Random rand = new Random();

        // Generate 3 random integers between 10 and 50 inclusive
        int num1 = rand.nextInt(41) + 10;
        int num2 = rand.nextInt(41) + 10;
        int num3 = rand.nextInt(41) + 10;

        int sum = num1 + num2 + num3;
        double average = sum / 3.0; // Divide by 3.0 to preserve decimal precision

        // Display results
        System.out.println("Random Numbers: " + num1 + ", " + num2 + ", " + num3);
        System.out.println("Sum: " + sum);
        System.out.printf("Average: %.2f\n", average);
    }
}

