/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week2;

/**
 *
 * @author umr
 */
    import java.text.DecimalFormat;

public class Question7 {

    public static void main(String[] args) {
        String text = "Not Javascript";
        double number = 655.123;
        int integerNum = 7;

        System.out.printf("1. Text = %s, Number = %f\n", text, number);

        System.out.printf("2. %.2f\n", number);

        System.out.printf("3. |%15s| |%15.2f|\n", text, number);

        System.out.printf("4. |%-15s| |%-15.2f|\n", text, number);

        System.out.printf("5. %08d\n", integerNum);

        System.out.printf("6. %e\n", number);

        System.out.printf("7. %S\n", text);

        DecimalFormat currencyFormat = new DecimalFormat("RM #,##0.00");
        System.out.println("8. " + currencyFormat.format(number));

        double percent = 0.854;
        System.out.printf("9. %.1f%%\n", percent * 100);

        System.out.printf("10. Hex = %X, Octal = %o\n", integerNum, integerNum);
    }
}
