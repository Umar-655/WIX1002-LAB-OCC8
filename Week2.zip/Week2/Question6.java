/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week2;

/**
 *
 * @author umr
 */
import java.util.Scanner;

public class Question6 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the amount of water in gram: ");
        double waterInGrams = input.nextDouble();

        System.out.print("Enter the initial temperature in Fahrenheit: ");
        double initialFahrenheit = input.nextDouble();

        System.out.print("Enter the final temperature in Fahrenheit: ");
        double finalFahrenheit = input.nextDouble();

        double M = waterInGrams / 1000.0;

        double initialCelsius = (initialFahrenheit - 32) / 1.8;
        double finalCelsius = (finalFahrenheit - 32) / 1.8;

        double Q = M * (finalCelsius - initialCelsius) * 4184;

        // Display the output in scientific notation (%e)
        System.out.printf("The energy needed is %e\n", Q);

        input.close();
    }
}
    

