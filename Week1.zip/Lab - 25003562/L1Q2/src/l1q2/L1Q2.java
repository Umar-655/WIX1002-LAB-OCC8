/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package l1q2;

/**
 *
 * @author Ezzey Afidzi
 */
public class L1Q2 {
    
                   
   
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("""
                            Name     :Ezzey
                            Matrics  :25002298
                            Email    :ezzeyafidzi10@gmail.com
                            Address  :Kajang
                            Contact  :0124899252
                           """); 
    }
}

 



 

