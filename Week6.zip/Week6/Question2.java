/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week6;

/**
 *
 * @author umr
 */
public class Question2 {
    public static void main(String[] args) {
        int size = 5;

        // 1. Right-angled Triangle
        System.out.println("Triangle:");
        for (int i = 1; i <= size; i++) {
            multiPrint(i, '*');
            System.out.println();
        }

        // 2. Diamond
        System.out.println("\nDiamond:");
        // Top half
        for (int i = 1; i <= size; i++) {
            multiPrint(size - i, ' ');
            multiPrint(2 * i - 1, '*');
            System.out.println();
        }
        // Bottom half
        for (int i = size - 1; i >= 1; i--) {
            multiPrint(size - i, ' ');
            multiPrint(2 * i - 1, '*');
            System.out.println();
        }
    }

    public static void multiPrint(int n, char c) {
        for (int i = 0; i < n; i++) {
            System.out.print(c);
        }
    }
}