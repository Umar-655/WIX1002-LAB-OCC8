/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week6;

/**
 *
 * @author umr
 */
import java.util.Arrays;
import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextInt();
        }

        reverseElements(numbers);
        System.out.println("Reversed elements: " + Arrays.toString(numbers));
        scanner.close();
    }

    public static void reverseElements(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            int num = arr[i];
            int reversed = 0;
            
            while (num != 0) {
                int digit = num % 10;
                reversed = reversed * 10 + digit;
                num /= 10;
            }
            arr[i] = reversed;
        }
    }
}