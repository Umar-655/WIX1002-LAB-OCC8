/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week6;

/**
 *
 * @author umr
 */
    public class Question1 {
    public static void main(String[] args) {
        System.out.println("First 20 triangular numbers:");
        for (int i = 1; i <= 20; i++) {
            System.out.print(getTriangular(i) + " ");
        }
    }

    public static int getTriangular(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}
